#include <stdio.h>
struct node
{
	int value;
	struct node * ptr;
};
int enqueue(struct node * ptr1,struct node * ptr2){
	/*enqueues ptr2 after ptr1*/
	struct node * ptr3;
	printf("enqueue...\n");
	ptr3->ptr = ptr1->ptr;
	ptr1->ptr = ptr2->ptr;
	ptr2->ptr = ptr3->ptr;
}
int show(struct node * ptra){
	/*shows a particular element of the queue*/
	printf("\n%p\t", ptra);
	printf("{%d\t", ptra->value);
	printf("%p}\n", ptra->ptr);
}
int show_q(struct node * ptra){
	/*shows all the elements of the queue*/
	while(ptra->ptr){
		show(ptra);
		ptra=ptra->ptr;
	}

}
